from typing import Final
import os
from discord import Intents, Client, Message
from flask import Flask
from threading import Thread

# Load the token from .env file
TOKEN: Final[str] = os.getenv('DISCORD_TOKEN')

# Set up bot permissions (intents)
intents: Intents = Intents.default()
intents.message_content = True  # This allows the bot to read messages
client: Client = Client(intents=intents)


# Function to get the bot's response based on what the user typed
def get_response(user_input: str) -> str:
    """
    This function takes what the user typed and returns the appropriate response.
    Add more subjects here as you need them!
    """
    lowered: str = user_input.lower(
    )  # Convert to lowercase so !AP Chemistry and !ap chemistry both work

    # AP SUBJECTS
    if 'ap art history' in lowered or 'apah' in lowered or 'ap ah' in lowered:
        return """**🎨 AP Art History Resources:**
    • Khan Academy: https://www.khanacademy.org/humanities/ap-art-history
    • Study Sheets: <https://knowt.com/exams/AP/AP-Art-History>
    • Smarthistory (recommended): <https://smarthistory.org/>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap biology' in lowered or 'ap bio' in lowered:
        return """**🧬 AP Biology Resources:**
    • Khan Academy: <https://www.khanacademy.org/science/ap-biology>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Biology>
    • Amoeba Sisters: <https://www.youtube.com/@AmoebaSister>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap precalculus' in lowered or 'ap precalc' in lowered:
        return """**📐 AP Precalculus Resources:**
    • Khan Academy: <https://www.khanacademy.org/math/precalculus>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Precalculus>
    • Organic Chemistry Tutor: <https://www.youtube.com/@TheOrganicChemistryTutor>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap calculus ab' in lowered or 'ap calc ab' in lowered or 'calc ab' in lowered:
        return """**📐 AP Calculus AB Resources:**
    • Khan Academy: <https://www.khanacademy.org/math/ap-calculus-ab>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Calculus-AB>
    • Organic Chemistry Tutor: <https://www.youtube.com/@TheOrganicChemistryTutor>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap calculus bc' in lowered or 'ap calc bc' in lowered or 'calc bc' in lowered:
        return """**📐 AP Calculus BC Resources:**
    • Khan Academy: <https://www.khanacademy.org/math/ap-calculus-bc>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Calculus-BC>
    • Organic Chemistry Tutor: <https://www.youtube.com/@TheOrganicChemistryTutor>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap chemistry' in lowered or 'ap chem' in lowered:
        return """**🧪 AP Chemistry Resources:**
    • Khan Academy: <https://www.khanacademy.org/science/ap-chemistry>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Chemistry>
    • Organic Chemistry Tutor: <https://www.youtube.com/@TheOrganicChemistryTutor>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap chinese' in lowered:
        return """**🇨🇳 AP Chinese Resources:**
    • Study Sheets: <https://knowt.com/exams/AP/AP-Chinese-Language-and-Culture>
    • Grammar: <https://resources.allsetlearning.com/chinese/grammar>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap comparative government' in lowered or 'ap comp gov' in lowered:
        return """**🏛️ AP Comparative Government Resources:**
    • Study Sheets: <https://knowt.com/exams/AP/AP-Comparative-Government-and-Politics>
    • Heimler's History: <https://www.youtube.com/@HeimlerHistory>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap computer science' in lowered or 'ap cs' in lowered or 'apcsa' in lowered or 'apcs' in lowered:
        return """**</> AP Computer Science Resources:**
    • Study Sheets: <https://knowt.com/exams/AP/AP-Computer-Science-Principles>
    • Free Harvard course: https://cs50.harvard.edu/>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap english literature' in lowered or 'ap lit' in lowered or 'ap english lit' in lowered:
        return """**📚 AP English Literature Resources:**
    • Study Sheets: <https://knowt.com/exams/AP/AP-English-Literature-and-Composition>
    • Crash Course: <https://www.youtube.com/crashcourse>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap english language' in lowered or 'ap lang' in lowered or 'ap english lang' in lowered:
        return """**📚 AP English Language Resources:**
    • Khan Academy: <https://www.khanacademy.org/ela>
    • Study Sheets: <https://knowt.com/exams/AP/AP-English-Language-and-Composition>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap environmental science' in lowered or 'apes' in lowered:
        return """**🌱 AP Environmental Science Resources:**
    • Khan Academy: <https://www.khanacademy.org/science/ap-biology>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Environmental-Science>
    • Crash Course: <https://www.youtube.com/crashcourse>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap european history' in lowered or 'ap euro' in lowered:
        return """**🇪🇺 AP European History Resources:**
    • Khan Academy: <https://www.khanacademy.org/humanities/world-history>
    • Study Sheets: <https://knowt.com/exams/AP/AP-European-History>
    • Heimler's History: <https://www.youtube.com/@HeimlerHistory>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap french' in lowered:
        return """**🇫🇷 AP French Resources:**
    • Study Sheets: <https://knowt.com/exams/AP/AP-French-Language-and-Culture>
    • French Articles (Recommended): <https://savoirs.rfi.fr/fr/apprendre-enseigner>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap human geography' in lowered or 'ap hug' in lowered or 'aphug' in lowered:
        return """**🌎 AP Human Geography Resources:**
    • Khan Academy: <https://www.khanacademy.org/>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Human-Geography>
    • Crash Course Geography: <https://www.youtube.com/crashcourse>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap physics 1' in lowered or 'ap physics one' in lowered:
        return """**🚀 AP Physics 1 Resources:**
    • Khan Academy: <https://www.khanacademy.org/science/ap-physics-1>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Physics-1_Algebra.Based>
    • Free MIT Courses: <https://ocw.mit.edu/>
    • The Organic Chemistry Tutor: <https://www.youtube.com/@TheOrganicChemistryTutor>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap physics c' in lowered or 'ap physics c: mechanics' in lowered or 'ap physics c mechanics' in lowered or 'ap physics c: mech' in lowered or 'ap physics c mech' in lowered:
        return """**🚀 AP Physics C: Mechanics Resources:**
    • Khan Academy: <https://www.khanacademy.org/science/ap-physics-c-mechanics>
    • Free MIT Courses: <https://ocw.mit.edu/>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Physics-C_Mechanics>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap psychology' in lowered or 'ap psych' in lowered:
        return """**🧠 AP Psychology Resources:**
    • Khan Academy: <https://www.khanacademy.org/science/ap-psychology>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Psychology>
    • Crash Course: <https://www.youtube.com/crashcourse>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap spanish language' in lowered or 'ap spanish' in lowered:
        return """**🇪🇸 AP Spanish Language Resources:**
    • Study Sheets: <https://knowt.com/exams/AP/AP-Spanish-Language-and-Culture>
    • SpanishDict: <https://www.spanishdict.com/>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap statistics' in lowered or 'ap stats' in lowered or 'ap stat' in lowered:
        return """**📊 AP Statistics Resources:**
    • Khan Academy: <https://www.khanacademy.org/math/ap-statistics>
    • Study Sheets: <https://knowt.com/exams/AP/AP-Statistics>
    • Crash Course: <https://www.youtube.com/crashcourse>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap studio art' in lowered:
        return """**🎨 AP Studio Art Resources:**
    • Student Art Guide: <https://www.studentartguide.com/>
    • Ctrl+Paint (digital art): <https://www.ctrlpaint.com/>
    • Proko (hand art): <https://www.proko.com/>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap us government' in lowered or 'ap gov' in lowered or 'ap us gov' in lowered:
        return """**🏛️ AP US Government Resources:**
    • Khan Academy: <https://www.khanacademy.org/humanities/us-government>
    • Study Sheets: <https://knowt.com/exams/AP/AP-United-States-Government-and-Politics>
    • Heimler's History: <https://www.youtube.com/@HeimlerHistory>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap us history' in lowered or 'apush' in lowered:
        return """**🇺🇸 AP US History Resources:**
    • Khan Academy: <https://www.khanacademy.org/humanities/us-history>
    • Study Sheets: <https://knowt.com/exams/AP/AP-United-States-History>
    • Heimler's History: <https://www.youtube.com/@HeimlerHistory>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'ap world history' in lowered or 'ap world' in lowered:
        return """**🌍 AP World History Resources:**
    • Khan Academy: <https://www.khanacademy.org/humanities/world-history>
    • Heimler's History: <https://www.youtube.com/@HeimlerHistory>
    • AP Classroom: <https://apstudents.collegeboard.org/>"""

    elif 'sat' in lowered:
        return """**📚 SAT Resources:**
    • CrackSAT: <https://www.cracksat.net/index.html>
    • SAT Question Bank: <https://satsuitequestionbank.collegeboard.org/>
    • Practice Tests: <https://bluebook.collegeboard.org/students/download-bluebook>
    • BHS offers SAT tutoring; ask your counselor!"""

    elif 'act' in lowered:
        return """**📚 ACT Resources:**
    • CrackAB: <https://www.crackab.com/>
    • Practice Tests: <https://www.act.org/content/act/en/products-and-services/the-act/test-preparation.html>"""

    # Help command - shows all available commands
    elif lowered == '!help' or lowered == 'help':
        return """**Here's what I can tutor you in:**

**AP Courses:**
`!ap art history`
`!ap biology`
`!ap precalculus`
`!ap calculus ab`
`!ap calculus bc`
`!ap chemistry`
`!ap chinese`
`!ap comparative government`
`!ap computer science`
`!ap english literature`
`!ap english language`
`!ap environmental science`
`!ap european history`
`!ap french`
`!ap human geography`
`!ap physics 1`
`!ap physics c: mechanics`
`!ap psychology`
`!ap spanish language`
`!ap statistics`
`!ap studio art`
`!ap us government`
`!ap us history`
`!ap world history`

**SAT Prep:**
`!sat`

**ACT Prep:**
`!act`

Type anything above and I'll help you 👆🏻"""

    # If the message starts with "!" but isn't recognized
    elif lowered.startswith('!'):
        return 'I don\'t understand that. Type `!help` to see what I can do!'

    # If it doesn't start with "!", don't respond
    else:
        return None


# Function to send messages
async def send_message(message: Message, user_message: str) -> None:
    """
    This function handles sending the bot's response.
    It checks if the message should be private (DM) or public (in channel).
    """
    if not user_message:
        print('(Message was empty because intents were not enabled probably)')
        return

    # If the message starts with "?", send response as a DM
    is_private = False
    if user_message[0] == '?':
        user_message = user_message[1:]
        is_private = True

    try:
        response: str = get_response(user_message)
        
        # If get_response returns None, don't send anything (for normal chat messages)
        if response is None:
            return

        # Send as DM or in the channel
        if is_private:
            await message.author.send(response)
        else:
            await message.channel.send(response)
    except Exception as e:
        print(f'Error: {e}')


# Event: When the bot successfully connects to Discord
@client.event
async def on_ready() -> None:
    """
    This runs once when the bot starts up and connects to Discord.
    """
    print(f'{client.user} is now running!')


# Event: When someone sends a message in a channel the bot can see
@client.event
async def on_message(message: Message) -> None:
    """
    This runs every time someone sends a message.
    The bot will read the message and respond ONLY if it starts with "!"
    """
    # Ignore messages from the bot itself (prevents infinite loops!)
    if message.author == client.user:
        return

    # ONLY respond if the message starts with "!"
    if not message.content.startswith('!') or message.content.strip() == '!':
        return

    # Get info about the message
    username: str = str(message.author)
    user_message: str = message.content
    channel: str = str(message.channel)

    # Print to console so you can see what's happening
    print(f'[{channel}] {username}: "{user_message}"')

    # Process the message and send a response if needed
    await send_message(message, user_message)


# Main function to run the bot
def main() -> None:
    """
    This starts the bot and connects it to Discord using your token.
    """
    client.run(token=TOKEN)


# This runs the main function when you run the script
if __name__ == '__main__':
    main()